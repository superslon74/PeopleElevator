package peopleelevator;
import java.util.ArrayList;
/*  @author Genadiy 
 09.03.2020
e-mail:superslon74@gmail.com
*/
public class BaseMethod {
    static int NumberFloors; 
    static int NumberPeople; 
    static int NextFloor;
    
    static int y;
    static int down;
    static int top;
        
    static int onestart;
    static int twostart;
       
    static ArrayList<Integer> elevatorroom;
    static ArrayList<ElevatorPassenger> listtwoone; 
    static ArrayList<ArrayList<ElevatorPassenger>> listone;
       
    static ArrayList<ElevatorPassenger> listtwo;
    static ElevatorPassenger  elevatorpassenger;
    
    static void initStart(){
        elevatorroom = new ArrayList<Integer>();
        NumberFloors = GenerateValues.NumberFloors(); 
        listone = new ArrayList<ArrayList<ElevatorPassenger>>();
        y=0;
        onestart =0;
        twostart =0;
       }
    
    static void Print(String str,int i){
    if(i==0){ System.out.print(str);}
    else { System.out.println("");  }
    }
    
    static void initPeopleAndFloorsAndElevator(){
     for(int a=1;a<(NumberFloors+1);a++){
            NumberPeople = GenerateValues.NumberPeople();
            listtwo = new ArrayList<ElevatorPassenger>();
            
            for(int b=1;b<(NumberPeople+1);b++){
            NextFloor =  GenerateValues.NextFloor(NumberFloors);  
            if(NextFloor==a)NextFloor++;
             
            elevatorpassenger = new ElevatorPassenger(a,NextFloor);
            listtwo.add(elevatorpassenger);
                                              }
            listone.add(listtwo);
                                               } 
     }
         
    static void insertPeople(ArrayList<ElevatorPassenger> listtwoone2){
        listtwoone = listtwoone2;//
    }
     
     static void insertPeopleArray(ElevatorPassenger  elevatorpassenger2){
        elevatorpassenger = elevatorpassenger2;//
    }
  
     static void addPeople(int floorNext){
        elevatorroom.add(floorNext);
    }
    
     static void updatePeople(int y,ArrayList<ElevatorPassenger> listtwoone){
       listone.set(y, listtwoone);  //
       insertPeople( listone.get(y));    //
       Print("",1);
       Print(" People on Floor ",0);
       }  
     
    static void PrintLn(int f){
          if(f==0){
        Print(" Need down ",0);
        Print("",1);
                  }
          else {  
        Print(" Need to top ",0);
        Print("",1);
               }
          }
    
    static void Remove(int n){
             Print(" Left the elevator "+ elevatorroom.get(n)+" |  ",0);   //
             elevatorroom.remove(n);
    }
                                                  
    static void insertAddPeople(ArrayList<ElevatorPassenger> listtwoone,ElevatorPassenger  elevatorpassenger){
         insertPeopleArray(listtwoone.get(0));      //
         addPeople(elevatorpassenger.getFloorNext());   // 
         Print(" Еntered the elevator "+elevatorpassenger.getFloorNext()+" |  ",0);
         listtwoone.remove(0);
       }                                             

   
    
}
