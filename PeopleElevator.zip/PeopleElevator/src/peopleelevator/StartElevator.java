package peopleelevator;
/*  @author Genadiy 
 09.03.2020
e-mail:superslon74@gmail.com
*/
import java.util.ArrayList;

public class StartElevator extends BaseMethod{

    public StartElevator() {
           initStart();
           initPeopleAndFloorsAndElevator();
    }
     
    static void DownOrTop(){
      if(y==0){ 
              y++; 
              PrintLn(1);
              } else {     
                      down=0;
                      top=0;
                      for(int v=0;v<elevatorroom.size();v++){
                      if((y+1)>elevatorroom.get(v)){ down++;}
                      else 
                      if((y+1)<elevatorroom.get(v)){ top++;}    
                                                            }
                      if(elevatorroom.size()==0) { y++;} 
                      else  
                      if(down>top){ 
                                   y--; 
                                   PrintLn(0);
                                  }
                      else { 
                            y++; 
                            PrintLn(1);
                           } 
                       }
                          }
    
    public static void oneEtapGo(int y){
           Print(" Number Floor "+(y+1),0);
           Print("",1);        
           insertPeople( listone.get(y));                    
           Print(" People on Floor ",0);
           newPeople(1);
           onestart=1;
           Print("",1);
           Print(" People in the elevator go to the next floors ",0);
                                      }

    public static void newPeople(int v){
         if(v==0){
              for(int x=0;x<listtwoone.size();x++){
                insertPeopleArray(listtwoone.get(x));       
                Print(" nextfloor "+elevatorpassenger.getFloorNext()+" | ",0);                          
                                                  }
                }
         else 
                {
              for(int x=0;x<listtwoone.size();x++){
                insertPeopleArray(listtwoone.get(x));         
                if(y==0){ if(x<5){  
                          addPeople(elevatorpassenger.getFloorNext());      
                                 } 
                        }   
                Print(" nextfloor "+elevatorpassenger.getFloorNext()+" | ",0);
                                                  }
                }
      }
    
    public static void addPeoplElevator(){
        for(int e2=0;e2<5;e2++){ 
               if(elevatorroom.size()<5){
                                          if(listtwoone.size()>0){
                                              insertAddPeople(listtwoone,elevatorpassenger);       
                                                                 }
                                        }
                               }      
                                         }
    
    
    public static void deletePeopleElevator()
    {
        for(int e=0;e<5;e++){
            for(int n=0;n<elevatorroom.size();n++){
                        if((y+1)==elevatorroom.get(n)){
                        Remove(n);   
                        break;
                                                      } 
                                                  }
                           }
    }
        
        public void goElevator(){
    
        while(y<listone.size()){ 
              oneEtapGo(y);
        for(int n=0;n<elevatorroom.size();n++){ 
                Print(" nextfloor "+ elevatorroom.get(n)+" |  ",0);
                                              } 
        Print("",1);
        if(y==0 && twostart==0){ if( listtwoone.size()<5) {  listtwoone.clear(); }
                                else { listtwoone.removeAll(listtwoone.subList(0,5)); }
        updatePeople(y,listtwoone);
        newPeople(0);
        Print("",1);
                             }
        else
        if(y==0 && twostart==1){  
        deletePeopleElevator();
        Print("",1);
        addPeoplElevator();
        updatePeople(y,listtwoone);
        newPeople(1);
        Print("",1);
                    } else {
        deletePeopleElevator();  
        Print("",1);
        addPeoplElevator();
        updatePeople(y,listtwoone);
        newPeople(1);
        Print("",1);
        Print("",1);   
        }
        twostart=1;
        DownOrTop();
        } 
   }
 }