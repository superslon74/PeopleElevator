package peopleelevator;
/*  @author Genadiy 
 09.03.2020
e-mail:superslon74@gmail.com
*/

public class ElevatorPassenger {
   private int FloorStart;
   private int FloorNext;

    public ElevatorPassenger(int FloorStart, int FloorNext) {
        this.FloorStart = FloorStart;
        this.FloorNext = FloorNext;
    }

    public int getFloorStart() {
        return FloorStart;
    }

    public void setFloorStart(int FloorStart) {
        this.FloorStart = FloorStart;
    }

    public int getFloorNext() {
        return FloorNext;
    }

    public void setFloorNext(int FloorNext) {
        this.FloorNext = FloorNext;
    }
   
   
    
}
