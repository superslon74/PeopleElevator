package peopleelevator;

/*  @author Genadiy 
 09.03.2020
e-mail:superslon74@gmail.com
*/

import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.Iterator;
import java.util.List;

public class PeopleElevator {
   
     public static void main(String[] args) {
          ArrayList<Integer> elevatorroom = null;
          elevatorroom = new ArrayList<Integer>();
             ArrayList<ElevatorPassenger> listtwoone;    
            int NumberFloors = (int)(( Math.random() * (20 - 5) ) + 5); 
              //   int NumberFloors = 5;//(int)(( Math.random() * (20 - 5) ) + 5); 
            ArrayList<ArrayList<ElevatorPassenger>> listone = null;
            listone = new ArrayList<ArrayList<ElevatorPassenger>>();
            for(int a=1;a<(NumberFloors+1);a++){
            int NumberPeople = (int)(( Math.random() * (10 - 0) ) + 0); 
            ArrayList<ElevatorPassenger> listtwo = null;
            listtwo = new ArrayList<ElevatorPassenger>();
        
            for(int b=1;b<(NumberPeople+1);b++){
            int NextFloor = (int)(( Math.random() * (NumberFloors - 1) ) + 1);   
            if(NextFloor==a)NextFloor++;
      
            ElevatorPassenger  elevatorpassenger = null;
            elevatorpassenger = new ElevatorPassenger(a,NextFloor);
            listtwo.add(elevatorpassenger);
                                               }
            listone.add(listtwo);
                                               } 
            int size =listone.size();
            int y=0;
            
            int onestart =0;
            int twostart =0;
            
        while(y<size){         
        System.out.println(" Number Floor "+(y+1));
                  listtwoone = null;
                  listtwoone = listone.get(y);
        System.out.print(" People on Floor ");
     
        for(int x=0;x<listtwoone.size();x++){
                                             ElevatorPassenger elevatorpassengerone = null;
                                             elevatorpassengerone = listtwoone.get(x);
               if(onestart==0){                  
               if(y==0){ if(x<5){ elevatorroom.add(elevatorpassengerone.getFloorNext()); } }   
                              }
               System.out.print(" nextfloor "+elevatorpassengerone.getFloorNext()+" | ");
                                            }
        onestart=1;
   
       System.out.println("");  
       System.out.print(" People in the elevator go to the next floors ");
   
       for(int n=0;n<elevatorroom.size();n++){ System.out.print(" nextfloor "+ elevatorroom.get(n)+" |  "); } 
       System.out.println("");
        
       if(y==0 && twostart==0){ if( listtwoone.size()<5) {  listtwoone.clear(); }
                                else { listtwoone.removeAll(listtwoone.subList(0,5)); }
       listone.set(y, listtwoone);  
       listtwoone = listone.get(y);
    
       System.out.print(" People on Floor - ");
       for(int x=0;x<listtwoone.size();x++){
                                            ElevatorPassenger elevatorpassengerone2 = null;
                                            elevatorpassengerone2 = listtwoone.get(x);
       System.out.print(" nextfloor "+elevatorpassengerone2.getFloorNext()+" | ");
                                           }
       System.out.println("");
                             }
      else
      if(y==0 && twostart==1){  for(int e=0;e<5;e++){
                                                    for(int n=0;n<elevatorroom.size();n++){
                                                    if((y+1)==elevatorroom.get(n)){
             
       System.out.print(" Left the elevator "+ elevatorroom.get(n)+" |  ");
       elevatorroom.remove(n);   
       break;
             } 
           } 
          }
        
       System.out.println(""); 
       for(int e2=0;e2<5;e2++){
                              if(elevatorroom.size()<5){
                                                        if( listtwoone.size()>0){
                                                                                 ElevatorPassenger elevatorpassengerone3 = null;
                                                                                 elevatorpassengerone3 = listtwoone.get(0);
                                                                                 elevatorroom.add(elevatorpassengerone3.getFloorNext()); 
         System.out.print(" Entered the elevator "+elevatorpassengerone3.getFloorNext()+" |  ");
         listtwoone.remove(0);
                                                                                 }
                                                       }
                             }
        
        
       listone.set(y, listtwoone);  
       listtwoone = listone.get(y);
       System.out.println(""); 
       System.out.print(" People on Floor ");
     
       for(int x=0;x<listtwoone.size();x++){
                                            ElevatorPassenger elevatorpassengerone = null;
                                            elevatorpassengerone = listtwoone.get(x);
                                            if(y==0){ if(x<5){ elevatorroom.add(elevatorpassengerone.getFloorNext()); } 
                                                    }   
        System.out.print(" nextfloor "+elevatorpassengerone.getFloorNext()+" | ");
                                           }
        System.out.println("");
                    } else {
        
        for(int e=0;e<5;e++){
                            for(int n=0;n<elevatorroom.size();n++){ if((y+1)==elevatorroom.get(n)){ 
        System.out.print(" Left the elevator "+ elevatorroom.get(n)+" |  ");
        elevatorroom.remove(n);   
        break;                                                                                     } 
                                                                  } 
                           }
        System.out.println(""); 
        for(int e2=0;e2<5;e2++){ if(elevatorroom.size()<5){
                                                           if( listtwoone.size()>0){
                                                                                    ElevatorPassenger elevatorpassengerone3 = null;
                                                                                    elevatorpassengerone3 = listtwoone.get(0);
                                                                                    elevatorroom.add(elevatorpassengerone3.getFloorNext()); 
         System.out.print(" Еntered the elevator "+elevatorpassengerone3.getFloorNext()+" |  ");
         listtwoone.remove(0);
                                                                                   }
                                                         }
                               }
        listone.set(y, listtwoone);  
        listtwoone = listone.get(y);
        System.out.println(""); 
        System.out.print(" People on Floor ");
     
        for(int x=0;x<listtwoone.size();x++){
                                             ElevatorPassenger elevatorpassengerone = null;
                                             elevatorpassengerone = listtwoone.get(x);
         if(y==0){ if(x<5){  elevatorroom.add(elevatorpassengerone.getFloorNext());
                          } 
                 }   
        System.out.print(" nextfloor "+elevatorpassengerone.getFloorNext()+" | ");
                     }
        System.out.println("");  
        System.out.println("");
        }
        twostart=1;
       if(y==0){ y++; System.out.println(" Need to top "); }
                                                            else {     
                                                                  int a=0;
                                                                  int b=0;
       for(int v=0;v<elevatorroom.size();v++){
                                              if((y+1)>elevatorroom.get(v)){ a++;}
                                              else if((y+1)<elevatorroom.get(v)){ b++;}    
                                              }
       if(elevatorroom.size()==0) { y++;}  else  if(a>b){ y--; System.out.println(" Need down ");}
                                           else {  y++; System.out.println(" Need to top ");}
    }
   }
   }
   }
