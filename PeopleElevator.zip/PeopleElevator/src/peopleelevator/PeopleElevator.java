package peopleelevator;
/*  @author Genadiy 
 09.03.2020
e-mail:superslon74@gmail.com
*/

import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.Iterator;
import java.util.List;

public class PeopleElevator {
      
        
     public static void main(String[] args) {
       
         StartElevator startelevator = new StartElevator();
                       startelevator.goElevator();
         
   }
   }
