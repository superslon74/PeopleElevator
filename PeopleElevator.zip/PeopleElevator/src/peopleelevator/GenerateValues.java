package peopleelevator;
/*  @author Genadiy 
 09.03.2020
e-mail:superslon74@gmail.com
*/
class GenerateValues {
    static int NumberFloors(){ return (int)(( Math.random() * (20 - 5) ) + 5); }
    static int NumberPeople(){ return (int)(( Math.random() * (10 - 0) ) + 0); }
    static int NextFloor(int i){ return (int)(( Math.random() * (i - 1) ) + 1);} 
}
